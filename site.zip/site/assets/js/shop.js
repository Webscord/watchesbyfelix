// Script spécifique pour la page boutique
document.addEventListener('DOMContentLoaded', function() {
    // Filtres de la boutique
    const collectionFilter = document.getElementById('collection-filter');
    const availabilityFilter = document.getElementById('availability-filter');
    const shopItems = document.querySelectorAll('.shop-item');
    
    // Fonction pour filtrer les produits
    function filterProducts() {
        const collectionValue = collectionFilter.value;
        const availabilityValue = availabilityFilter.value;
        
        shopItems.forEach(item => {
            const collectionMatch = collectionValue === 'all' || item.dataset.collection === collectionValue;
            const availabilityMatch = availabilityValue === 'all' || item.dataset.availability === availabilityValue;
            
            if (collectionMatch && availabilityMatch) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Ajouter les écouteurs d'événements aux filtres
    if (collectionFilter) {
        collectionFilter.addEventListener('change', filterProducts);
    }
    
    if (availabilityFilter) {
        availabilityFilter.addEventListener('change', filterProducts);
    }
    
    // Désactiver les liens sur les produits vendus
    const soldItems = document.querySelectorAll('.shop-item[data-availability="sold"]');
    soldItems.forEach(item => {
        item.style.cursor = 'default';
        item.addEventListener('click', function(e) {
            e.preventDefault();
        });
    });
    
    // Animation au survol des produits disponibles
    const availableItems = document.querySelectorAll('.shop-item[data-availability="available"]');
    availableItems.forEach(item => {
        const link = item.querySelector('.shop-item-link');
        if (link) {
            link.addEventListener('mouseenter', function() {
                const buyNowText = document.createElement('div');
                buyNowText.className = 'buy-now-overlay';
                buyNowText.innerHTML = '<span>Acheter maintenant</span>';
                item.querySelector('.shop-item-image').appendChild(buyNowText);
            });
            
            link.addEventListener('mouseleave', function() {
                const buyNowText = item.querySelector('.buy-now-overlay');
                if (buyNowText) {
                    buyNowText.remove();
                }
            });
        }
    });
});
