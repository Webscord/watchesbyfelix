// Script principal pour le site WatchesByFelix
document.addEventListener('DOMContentLoaded', function() {
    // Gestion du menu mobile
    const menuToggle = document.querySelector('.menu-toggle');
    const navList = document.querySelector('.nav-list');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            menuToggle.classList.toggle('active');
            navList.classList.toggle('active');
        });
    }
    
    // Header fixe avec changement au scroll
    const header = document.querySelector('.header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
    
    // Animation des témoignages (simple auto-scroll)
    const testimonialsSlider = document.querySelector('.testimonials-slider');
    
    if (testimonialsSlider && testimonialsSlider.children.length > 1) {
        let currentIndex = 0;
        const testimonials = testimonialsSlider.children;
        const slideWidth = testimonials[0].offsetWidth + parseInt(getComputedStyle(testimonials[0]).marginRight);
        
        setInterval(() => {
            currentIndex = (currentIndex + 1) % testimonials.length;
            testimonialsSlider.scrollTo({
                left: currentIndex * slideWidth,
                behavior: 'smooth'
            });
        }, 5000);
    }
    
    // Gestion des liens externes
    const externalLinks = document.querySelectorAll('a[target="_blank"]');
    
    externalLinks.forEach(link => {
        // Ajouter un attribut rel pour la sécurité
        link.setAttribute('rel', 'noopener noreferrer');
        
        // Ajouter une icône pour indiquer les liens externes
        if (!link.querySelector('.fa-external-link-alt')) {
            const icon = document.createElement('i');
            icon.className = 'fas fa-external-link-alt';
            icon.style.marginLeft = '5px';
            icon.style.fontSize = '0.8em';
            link.appendChild(icon);
        }
    });
});
